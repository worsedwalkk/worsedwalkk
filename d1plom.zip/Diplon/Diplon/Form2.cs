﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Diplon
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 LF = new Form1();
            LF.Show();
            this.Hide();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                guna2TextBox4.UseSystemPasswordChar = true;
                guna2TextBox5.UseSystemPasswordChar = true;
            }
            else
            {
                guna2TextBox4.UseSystemPasswordChar = false;
                guna2TextBox5.UseSystemPasswordChar = false;
            }
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            if (guna2TextBox4.Text != guna2TextBox5.Text)
            {
                MessageBox.Show("Пароли не совпадают.", "Ошибка");
                return;
            }

            PassValidation PassV = new PassValidation();
            if (PassV.Validation(guna2TextBox4.Text) == false)
            {
                return;
            }

            if (guna2TextBox4.Text == guna2TextBox3.Text)
            {
                MessageBox.Show("Пароль и логин не должны совпадать.", "Ошибка");
                return;
            }

            ValidationLogin LV = new ValidationLogin();
            if (LV.Validation(guna2TextBox3.Text) == false)
            {
                return;
            }
            else
            {
                Register(guna2TextBox3.Text, guna2TextBox4.Text);

                Form1 LF = new Form1();
                LF.Show();
                this.Hide();
            }
        }
        private void Register(string login, string password)
        {
            Hashing GH = new Hashing();
            string query = $"Insert into reg1st(Логин, Пароль) values('{login}', '{GH.Hash(password)}')";

            var dbquery = new DBquery();
            dbquery.queryExecute(query);
        }
    }
}
